/**
 * 环境配置。
 * 本地开发：微信开发者工具里勾选「不校验合法域名」，直接把 BASE_URL 指向本机 API。
 * 上线前：把 prod 的域名换成已备案 + HTTPS 的域名，并在小程序后台配置
 *        request 合法域名（API）与 uploadFile 合法域名（COS/CDN）。
 */

const ENV = 'dev'; // 'dev' | 'prod'

/**
 * 默认供同一台电脑的微信开发者工具使用。
 * 手机调试：把 127.0.0.1 改为 ipconfig 中电脑当前的局域网 IPv4，手机连接同一路由器。
 * 端口和 /api/v1 后缀保持不变。
 */
const DEV_API_URLS = ['127.0.0.1'].map(
  (host) => `http://${host}:3000/api/v1`
);

const ENVIRONMENTS = {
  dev: {
    apiBaseUrl: DEV_API_URLS[0],
    fallbackApiBaseUrls: DEV_API_URLS.slice(1),
    // 本地开发没有小程序 AppID 时，用 dev:<设备ID> 登录（后端 AUTH_DEV_MODE=true）
    useDevLogin: true,
    // STORAGE_DRIVER=local 时后端返回本地上传地址，无需 COS
    storageDriver: 'local'
  },
  prod: {
    apiBaseUrl: 'https://api.your-domain.com/api/v1',
    useDevLogin: false,
    storageDriver: 'cos'
  }
};

const current = ENVIRONMENTS[ENV] || ENVIRONMENTS.dev;

module.exports = {
  ENV,
  ...current,
  // 打开后地图页会在顶栏显示一行调试信息（updated 事件次数 / getRegion 结果 / 已等待秒数）。
  // 排查地图渲染问题时才需要打开；演示前保持关闭，否则顶栏会有调试灰字。
  debug: false,
  // 地图默认视角：大陆中心，防止拿不到定位时出现空白地图
  defaultCenter: { latitude: 34.2, longitude: 108.9, scale: 4 },
  // zoom 小于该值时后端返回城市聚合点
  clusterZoomThreshold: 9,
  maxPhotos: 9,
  maxPhotoMB: 10
};

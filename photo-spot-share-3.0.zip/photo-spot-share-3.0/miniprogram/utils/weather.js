const time = require('./shooting-time');
const numberText = (value, unit) => typeof value === 'number' && Number.isFinite(value) ? `${value}${unit}` : '—';
function decorate(payload) {
  const current = payload.current ? { ...payload.current,
    temperatureText: numberText(payload.current.temperature, '℃'), humidityText: numberText(payload.current.humidity, '%'),
    updatedText: time.beijingTime(payload.current.reportTime) } : null;
  const forecast = (payload.forecast || []).map(day => ({ ...day,
    dateLabel: day.date.slice(5).replace('-', '/'),
    temperatureText: `${numberText(day.nightTemperature, '℃')} / ${numberText(day.dayTemperature, '℃')}` }));
  return { ...payload, current, forecast, forecastUpdatedText: time.beijingTime(payload.forecastReportTime) };
}
module.exports = { decorate };

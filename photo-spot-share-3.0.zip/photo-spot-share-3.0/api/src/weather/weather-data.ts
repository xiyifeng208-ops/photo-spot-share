export interface CurrentWeather {
  weather: string; temperature: number | null; humidity: number | null;
  windDirection: string; windPower: string; reportTime: string | null; stale: boolean;
}
export interface ForecastDay {
  date: string; dayWeather: string; nightWeather: string;
  dayTemperature: number | null; nightTemperature: number | null;
  dayWind: string; nightWind: string; dayPower: string; nightPower: string;
}
export const weatherText = (value: unknown): string => typeof value === 'string' ? value.trim().slice(0, 80) : '';
export function weatherNumber(value: unknown, min: number, max: number): number | null {
  if (typeof value !== 'string' && typeof value !== 'number') return null;
  if (typeof value === 'string' && (!value.trim() || !/^-?\d+(\.\d+)?$/.test(value.trim()))) return null;
  const number = Number(value);
  return Number.isFinite(number) && number >= min && number <= max ? number : null;
}
export function reportTime(value: unknown): string | null {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(value)) return null;
  const date = new Date(value.replace(' ', 'T') + '+08:00');
  if (!Number.isFinite(date.getTime())) return null;
  if (new Date(date.getTime() + 8 * 3600000).toISOString().slice(0,19) !== value.replace(' ', 'T')) return null;
  return date.toISOString();
}
export function isStale(time: string | null, hours: number, now = Date.now()): boolean {
  if (!time) return true;
  const age = now - Date.parse(time);
  return age > hours * 3600000 || age < -10 * 60000;
}
export function normalizeCurrent(raw: Record<string, unknown>, now = Date.now()): CurrentWeather | null {
  const weather = weatherText(raw.weather);
  if (!weather) return null;
  const time = reportTime(raw.reporttime);
  return { weather, temperature: weatherNumber(raw.temperature, -90, 65),
    humidity: weatherNumber(raw.humidity, 0, 100), windDirection: weatherText(raw.winddirection),
    windPower: weatherText(raw.windpower), reportTime: time, stale: isStale(time, 3, now) };
}
export function normalizeForecast(raw: unknown): ForecastDay[] {
  if (!Array.isArray(raw)) return [];
  const days = new Map<string, ForecastDay>();
  for (const row of raw.slice(0, 16)) {
    if (!row || typeof row.date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(row.date)) continue;
    const parsed = new Date(row.date + 'T00:00:00Z');
    if (!Number.isFinite(parsed.getTime()) || parsed.toISOString().slice(0,10) !== row.date) continue;
    const dayWeather = weatherText(row.dayweather), nightWeather = weatherText(row.nightweather);
    if (!dayWeather && !nightWeather) continue;
    days.set(row.date, { date: row.date, dayWeather, nightWeather,
      dayTemperature: weatherNumber(row.daytemp,-90,65), nightTemperature: weatherNumber(row.nighttemp,-90,65),
      dayWind: weatherText(row.daywind), nightWind: weatherText(row.nightwind),
      dayPower: weatherText(row.daypower), nightPower: weatherText(row.nightpower) });
  }
  return [...days.values()].sort((a,b) => a.date.localeCompare(b.date));
}
/** Practical suggestions, not a prediction of sunset colors or a safety/flight assessment. */
export function shootingHints(weather: string, powers: string[], temperatures: (number | null)[], focal: string | null, difficulty: number | null): string[] {
  const hints: string[] = [];
  if (/雷|暴雨|暴雪|台风/.test(weather)) hints.push('有强对流或强降水相关天气描述，建议调整户外拍摄安排，并查看当地预警。');
  else if (/雨|雪/.test(weather)) hints.push('有雨雪天气描述，准备器材防水和防滑装备；可考虑有遮蔽的拍摄位置。');
  if (/雾|霾|沙|尘/.test(weather)) hints.push('远景清晰度可能受影响，可考虑近景或轮廓构图；以现场能见度为准。');
  else if (/阴|多云/.test(weather)) hints.push('阴天或多云时可尝试柔和光线下的细节、人像；云层变化仍会影响光线。');
  else if (/晴/.test(weather)) hints.push('晴天光比可能较大，可参考下方黄金时段，并留意高光曝光。');
  const wind = Math.max(0, ...powers.flatMap(p => (p.match(/\d+/g) || []).map(Number)));
  if (wind >= 5) hints.push('预报或实况风力较大，注意器材稳定，谨慎选择长曝光位置。');
  else if (focal === 'tele') hints.push('该机位推荐长焦，拍摄前检查快门速度与支撑稳定性。');
  if (focal === 'drone') hints.push('天气信息不能作为起飞依据，另行核对当地空域、现场阵风及设备限制。');
  if (temperatures.some(t => t !== null && t >= 35)) hints.push('气温较高，安排补水与遮阳，避免器材长时间暴晒。');
  if (temperatures.some(t => t !== null && t <= 0)) hints.push('气温较低，注意保暖与电池续航，留意现场结冰情况。');
  if (difficulty && difficulty >= 2 && /雨|雪/.test(weather)) hints.push('该机位需要步行或较难到达，雨雪时应重新评估到达路线。');
  if (!hints.length) hints.push('出发前核对现场天气与通行情况，并结合下方拍摄时间安排。');
  return hints.slice(0, 5);
}

// Offline page state tests: no external requests or user data writes.
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..'), require=createRequire(import.meta.url);
const tick=()=>new Promise(r=>setTimeout(r,0));
const event=(dataset,value)=>({currentTarget:{dataset},detail:{value}});
const prefs=()=>({enabled:true,useFavorites:true,bestTimes:[],bestSeasons:[],focalLengths:[],difficulties:[],learnedTags:[],dismissedCount:0});
let checks=0;
function check(name,condition){assert.ok(condition,name);console.log('[PASS] '+name);checks++;}
function harness(file){
 const calls=[],modals=[],toasts=[],app={globalData:{user:{id:'A'},lastLocation:null}};
 const request=options=>new Promise((resolve,reject)=>calls.push({...options,resolve,reject}));
 const auth={currentUser:()=>app.globalData.user,ensureLogin:()=>Promise.resolve(app.globalData.user)};
 const mocks={'../../utils/request':{request},'../../utils/auth':auth,
  '../../utils/format':require('../miniprogram/utils/format'), '../../utils/shooting-time':require('../miniprogram/utils/shooting-time'),
  '../../utils/weather':require('../miniprogram/utils/weather'), '../../data/cities':require('../miniprogram/data/cities'),
  '../../utils/geo':{getUserLocation:()=>Promise.resolve(null)}};
 let page;vm.runInNewContext(readFileSync(resolve(root,file),'utf8'),{Page:p=>page=p,require:key=>mocks[key],
  getApp:()=>app,setTimeout,clearTimeout,wx:{showModal:o=>modals.push(o),showToast:o=>toasts.push(o),navigateTo(){}}});
 page.setData=p=>Object.assign(page.data,p);return {page,calls,modals,toasts,app};
}
{
 const h=harness('miniprogram/pages/preferences/index.js');h.page.onLoad();await tick();
 h.calls[0].resolve(prefs());await tick();
 check('个人设置绑定当前账号',h.calls[0].boundUserId==='A'&&h.page.data.loaded);
 h.page.onOptionTap(event({field:'difficulties',value:'2'}));h.page.onOptionTap(event({field:'bestTimes',value:'night'}));
 const saving=h.page.onSave();const call=h.calls.at(-1);
 check('保存兴趣提交数值难度与合法标签',call.method==='PUT'&&call.data.difficulties[0]===2&&call.data.bestTimes[0]==='night');
 check('不提交可伪造的用户ID',!Object.hasOwn(call.data,'userId')&&call.boundUserId==='A');
 call.reject(new Error('断网'));await saving;
 check('保存失败保留选择并可重试',!h.page.data.saving&&h.page.data.prefs.bestTimes[0]==='night'&&h.page.data.error==='断网');
 const retry=h.page.onSave();h.calls.at(-1).resolve({...prefs(),bestTimes:['night'],difficulties:[2]});await retry;
 check('保存成功有反馈',h.page.data.notice.includes('已保存'));
 const n=h.calls.length;h.app.globalData.user={id:'B'};await h.page.onSave();
 check('账号变化时不把旧选择写给新账号',h.calls.length===n&&!h.page.data.loaded);
 h.page.onUnload();
}
{
 const h=harness('miniprogram/pages/preferences/index.js');h.page.onLoad();await tick();h.calls[0].resolve({...prefs(),dismissedCount:2});await tick();
 h.page.onReset();check('重置先说明保留收藏',h.modals[0].content.includes('收藏与作品会保留'));
 h.modals[0].success({confirm:true});const call=h.calls.at(-1);check('重置调用独立账号接口',call.url==='/recommendations/reset'&&call.boundUserId==='A');
 call.resolve({...prefs(),useFavorites:false});await tick();check('重置关闭学习且清空屏蔽记录',!h.page.data.prefs.useFavorites&&h.page.data.dismissedCount===0);
}
{
 const h=harness('miniprogram/pages/spot/detail.js');const p=h.page;
 p.unloaded=false;p.detailRevision=1;p.weatherRevision=0;p.shootingRevision=0;
 p.setData({spot:{id:'spot',status:'active'},shootingDate:'2026-09-27'});
 const first=p.loadWeather();const old=h.calls.at(-1);
 p.setData({shootingDate:'2026-09-28'});const second=p.loadWeather();const newer=h.calls.at(-1);
 check('天气用机位ID与所选日期，不用用户位置',newer.url==='/spots/spot/weather?date=2026-09-28');
 newer.resolve({date:'2026-09-28',status:'available',current:{temperature:0,humidity:null},forecast:[],hints:['new']});await second;
 old.resolve({date:'2026-09-27',current:null,forecast:[],hints:['old']});await first;
 check('晚到天气不覆盖新日期',p.data.weather.date==='2026-09-28'&&p.data.weather.hints[0]==='new');
 check('零度正常显示而缺值显示横线',p.data.weather.current.temperatureText==='0℃'&&p.data.weather.current.humidityText==='—');
 const failed=p.onWeatherRetry();h.calls.at(-1).reject(new Error('天气超时'));await failed;
 check('天气失败只影响自己的卡片',p.data.weatherError==='天气超时'&&!p.data.weatherLoading&&p.data.spot.id==='spot');
 const before=h.calls.length;const pending=p.onForecastTap(event({date:'2026-09-29'}));
 check('预报日期联动拍摄时间且独立请求',p.data.shootingDate==='2026-09-29'&&h.calls.length===before+2&&h.calls.at(-1).url.includes('shooting-times'));
 h.calls.at(-2).resolve({status:'unconfigured',current:null,forecast:[],message:'尚未配置'});
 h.calls.at(-1).resolve({date:'2026-09-29',notes:[]});await pending;await tick();
 check('未配置天气仍可显示拍摄时间',p.data.weather.status==='unconfigured'&&p.data.shootingLoaded);
 const late=p.loadWeather();p.onUnload();h.calls.at(-1).resolve({current:null,forecast:[]});await late;
 check('离开页面后丢弃天气结果',p.unloaded&&p.data.weather===null);
}
{
 const h=harness('miniprogram/pages/discover/index.js'),p=h.page;p.queryRevision=0;p.sortActionRevision=0;p.unloaded=false;
 let req=p.reload();h.calls.at(-1).resolve({items:[],nextCursor:null,recommendation:{personalized:true,canDismiss:true,message:'为你推荐'}});await req;
 check('发现页采用服务端推荐状态',p.data.recommendation.personalized);
 const dismiss=p.onDismissTap(event({id:'spot'}));const put=h.calls.at(-1);check('不感兴趣绑定当前账号',put.method==='PUT'&&put.boundUserId==='A');
 put.resolve({dismissed:true});await tick();h.calls.at(-1).resolve({items:[],nextCursor:null,recommendation:{canDismiss:true}});await dismiss;
 check('屏蔽后可撤销且从首页刷新',p.data.undoDismissId==='spot'&&!p.data.dismissPending&&!h.calls.at(-1).url.includes('cursor='));
 const undo=p.onUndoDismiss();h.calls.at(-1).resolve({restored:true});await tick();h.calls.at(-1).resolve({items:[],nextCursor:null});await undo;
 check('撤销恢复推荐资格',p.data.undoDismissId==='');
 req=p.reload();h.calls.at(-1).resolve({items:[],nextCursor:'old'});await req;
 req=p.loadMore();h.calls.at(-1).reject({statusCode:400,message:'分页游标无效或筛选变化'});await tick();
 check('偏好变化使旧游标失效时自动重新加载',!h.calls.at(-1).url.includes('cursor='));h.calls.at(-1).resolve({items:[],nextCursor:null});await req;
}
console.log(`结果：${checks}/${checks} 项通过`);

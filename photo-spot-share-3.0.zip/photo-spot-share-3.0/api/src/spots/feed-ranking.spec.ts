import { decodeRankedFeedCursor, encodeRankedFeedCursor, rankingQueryKey, type RankedFeedCursor } from './feed-ranking';

const cursor: RankedFeedCursor = {
  sort: 'recommended', order: 'desc', queryKey: rankingQueryKey(['上海市', 31, 121]),
  asOf: '2026-09-23T01:02:03.123Z', createdAt: '2026-09-18T01:02:03.123456Z',
  id: '11111111-1111-4111-8111-000000000001', value: 123456789,
};
describe('发现页显式排序游标', () => {
  it('保存评分基准和完整微秒，空游标表示第一页', () => {
    expect(decodeRankedFeedCursor(encodeRankedFeedCursor(cursor), cursor)).toEqual(cursor);
    expect(decodeRankedFeedCursor('', cursor)).toBeNull();
    expect(decodeRankedFeedCursor(undefined, cursor)).toBeNull();
  });
  it.each([{ sort: 'distance' }, { order: 'asc' }, { queryKey: rankingQueryKey(['杭州市']) }])('跨排序、方向或筛选拒绝旧游标 %j', patch => {
    expect(() => decodeRankedFeedCursor(encodeRankedFeedCursor({ ...cursor, ...patch } as RankedFeedCursor), cursor)).toThrow('分页游标无效');
  });
  it.each([
    { value: -1 }, { value: Infinity }, { value: null }, { value: '123' }, { value: 1e9 + 1 },
    { value: 0.1 }, { asOf: '2026-02-30T00:00:00.000Z' }, { createdAt: 'tomorrow' },
    { id: "' OR 1=1" },
  ])('拒绝畸形游标 %j', patch => {
    expect(() => decodeRankedFeedCursor(encodeRankedFeedCursor({ ...cursor, ...patch } as RankedFeedCursor), cursor)).toThrow();
  });
  it('距离保留小数，收藏量必须为整数', () => {
    const distance = { ...cursor, sort: 'distance' as const, order: 'asc' as const, value: 0.12345678 };
    expect(decodeRankedFeedCursor(encodeRankedFeedCursor(distance), distance)).toEqual(distance);
    const favorites = { ...distance, sort: 'favorites' as const };
    expect(() => decodeRankedFeedCursor(encodeRankedFeedCursor(favorites), favorites)).toThrow();
  });
});

import { ArrayMaxSize, ArrayUnique, IsArray, IsBoolean, IsIn } from 'class-validator';
import { BEST_TIMES, SEASONS, FOCAL_LENGTHS } from '../common/enums';

export class PreferencesDto {
  @IsBoolean() enabled!: boolean;
  @IsBoolean() useFavorites!: boolean;
  @IsArray() @ArrayUnique() @ArrayMaxSize(7) @IsIn(BEST_TIMES, { each: true }) bestTimes!: string[];
  @IsArray() @ArrayUnique() @ArrayMaxSize(4) @IsIn(SEASONS, { each: true }) bestSeasons!: string[];
  @IsArray() @ArrayUnique() @ArrayMaxSize(5) @IsIn(FOCAL_LENGTHS, { each: true }) focalLengths!: string[];
  @IsArray() @ArrayUnique() @ArrayMaxSize(3) @IsIn([1, 2, 3], { each: true }) difficulties!: number[];
}

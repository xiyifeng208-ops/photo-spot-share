import { Body, Controller, Delete, Get, Param, ParseUUIDPipe, Post, Put } from '@nestjs/common';
import { CurrentUser } from '../common/decorators/current-user.decorator';
import type { RequestUser } from '../common/guards/jwt-auth.guard';
import { RateLimit } from '../common/guards/rate-limit.guard';
import { PreferencesDto } from './preferences.dto';
import { RecommendationsService } from './recommendations.service';

@Controller('recommendations')
export class RecommendationsController {
  constructor(private readonly service: RecommendationsService) {}
  @Get('preferences') get(@CurrentUser() user: RequestUser) { return this.service.getSettings(user.id); }
  @Put('preferences') save(@CurrentUser() user: RequestUser, @Body() body: PreferencesDto) { return this.service.save(user.id, body); }
  @Post('reset') reset(@CurrentUser() user: RequestUser) { return this.service.reset(user.id); }
  @Put('dismissed/:id')
  @RateLimit({ scope: 'user-and-route', limit: 60, windowMs: 60_000 })
  dismiss(@CurrentUser() user: RequestUser, @Param('id', new ParseUUIDPipe()) id: string) { return this.service.dismiss(user.id, id); }
  @Delete('dismissed/:id') restoreOne(@CurrentUser() user: RequestUser, @Param('id', new ParseUUIDPipe()) id: string) { return this.service.restore(user.id, id); }
  @Delete('dismissed') restore(@CurrentUser() user: RequestUser) { return this.service.restore(user.id); }
}

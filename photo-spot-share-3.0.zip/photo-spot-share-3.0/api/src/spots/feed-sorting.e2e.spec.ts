import { randomUUID } from 'node:crypto';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { Client } from 'pg';
import { AppModule } from '../app.module';
import { AllExceptionsFilter } from '../common/filters/all-exceptions.filter';
import { ResponseInterceptor } from '../common/interceptors/response.interceptor';
import { runMigrations } from '../database/migration-runner';
import { distanceInMeters } from '../common/utils/geo.util';

const url = process.env.TEST_DATABASE_URL;
const describeWithDb = url ? describe : describe.skip;
describeWithDb('发现页四种排序与分页 (e2e)', () => {
  let app: INestApplication;
  let db: Client;
  const users = Array.from({ length: 50 }, () => randomUUID());
  const city = `sort-${randomUUID()}`;
  const origin = { lat: 31.23, lng: 121.47 };
  const now = Date.now();
  const fixture = (count: number, lat: number, ageDays: number, micro = '123456') => ({
    id: randomUUID(), count, lat, lng: origin.lng,
    createdAt: new Date(now - ageDays * 86400000).toISOString().replace(/\.\d{3}Z$/, `.${micro}Z`),
  });
  const spots = [fixture(50, 35.23, 90), fixture(10, 31.23, 7), fixture(2, 31.24, 1),
    fixture(0, 31.28, 1), fixture(2, 31.24, 1, '123457'), fixture(0, 31.28, 0.1)];

  beforeAll(async () => {
    if (!/^\/spot_test_[a-z0-9_]+$/.test(new URL(url!).pathname)) throw new Error('要求独立的 spot_test_* 数据库');
    Object.assign(process.env, { NODE_ENV: 'test', DATABASE_URL: url, DATABASE_SSL: 'false', AUTH_DEV_MODE: 'true',
      CONTENT_CHECK_ENABLED: 'false', STORAGE_DRIVER: 'local', AMAP_KEY: '' });
    await runMigrations(url!, () => undefined);
    db = new Client({ connectionString: url }); await db.connect();
    for (const id of users) await db.query('INSERT INTO users(id,openid) VALUES($1,$2)', [id, id]);
    for (const spot of spots) {
      await db.query(`INSERT INTO spots(id,user_id,title,province,city,lat,lng,location,created_at,best_times,best_seasons,focal_length,difficulty)
        VALUES($1,$2,$3,'测试省',$3,$4,$5,ST_SetSRID(ST_MakePoint($5,$4),4326)::geography,$6,'{night}','{winter}','tele',1)`,
      [spot.id, users[0], city, spot.lat, spot.lng, spot.createdAt]);
      for (const user of users.slice(0, spot.count)) await db.query('INSERT INTO spot_favorites(user_id,spot_id) VALUES($1,$2)', [user, spot.id]);
    }
    // Matching but unavailable content must not appear in any ordering.
    for (const status of ['hidden', 'pending', 'deleted']) {
      await db.query(`INSERT INTO spots(user_id,title,province,city,lat,lng,location,status)
        VALUES($1,$2,'测试省',$2,31.23,121.47,ST_SetSRID(ST_MakePoint(121.47,31.23),4326)::geography,$3)`, [users[0], city, status]);
    }
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();
    app = moduleRef.createNestApplication();
    app.setGlobalPrefix('api/v1');
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
    app.useGlobalFilters(new AllExceptionsFilter());
    app.useGlobalInterceptors(new ResponseInterceptor());
    await app.init();
  }, 60000);
  afterAll(async () => {
    await app?.close();
    if (db) { await db.query('DELETE FROM users WHERE id=ANY($1::uuid[])', [users]); await db.end(); }
  });

  const feed = (query: Record<string, string | undefined> = {}) => request(app.getHttpServer()).get('/api/v1/spots/feed').query({ city, ...query });
  const location = { viewerLat: String(origin.lat), viewerLng: String(origin.lng) };
  const tie = (a: typeof spots[number], b: typeof spots[number]) => b.createdAt.localeCompare(a.createdAt) || b.id.localeCompare(a.id);
  const value = (s: typeof spots[number], sort: string, asOf: string, located: boolean) => {
    if (sort === 'latest') return 0;
    if (sort === 'favorites') return s.count;
    const distance = distanceInMeters(origin, s);
    if (sort === 'distance') return distance;
    const recency = 1 / (1 + Math.max(0, Date.parse(asOf) - Date.parse(s.createdAt)) / (30 * 86400000));
    return (0.5 * s.count / (s.count + 10) + (located ? 0.3 / (1 + distance / 10000) : 0) + 0.2 * recency) / (located ? 1 : 0.7);
  };

  it.each([
    ['favorites','desc'], ['favorites','asc'], ['distance','asc'], ['distance','desc'],
    ['latest','desc'], ['latest','asc'], ['recommended','desc'],
  ])('%s/%s 对所有匹配作品排序，逐条翻页无重复或遗漏', async (sort, order) => {
    const first = await feed({ sort, order, ...location, limit: '1' }).expect(200);
    const asOf = JSON.parse(Buffer.from(first.body.data.nextCursor, 'base64url').toString()).asOf;
    const expected = spots.slice().sort((a, b) => {
      const delta = value(a, sort, asOf, true) - value(b, sort, asOf, true);
      return delta * (order === 'asc' ? 1 : -1) || tie(a, b) * (sort === 'latest' && order === 'asc' ? -1 : 1);
    }).map(s => s.id);
    const found = first.body.data.items.map((s: { id: string }) => s.id);
    let cursor = first.body.data.nextCursor;
    for (let page = 0; cursor && page < 10; page++) {
      const res = await feed({ sort, order, ...location, cursor, limit: '1' }).expect(200);
      found.push(...res.body.data.items.map((s: { id: string }) => s.id));
      cursor = res.body.data.nextCursor;
      if (cursor) expect(JSON.parse(Buffer.from(cursor, 'base64url').toString()).asOf).toBe(asOf);
    }
    expect(cursor).toBeNull();
    expect(found).toEqual(expected);
  });
  it('综合排序无定位时按 5:2 归一化收藏与新鲜度', async () => {
    const first = await feed({ sort: 'recommended', limit: '1' }).expect(200);
    const asOf = JSON.parse(Buffer.from(first.body.data.nextCursor, 'base64url').toString()).asOf;
    const expected = spots.slice().sort((a, b) => value(b, 'recommended', asOf, false) - value(a, 'recommended', asOf, false) || tie(a, b));
    const all = await feed({ sort: 'recommended' }).expect(200);
    expect(all.body.data.items.map((s: { id: string }) => s.id)).toEqual(expected.map(s => s.id));
    expect(all.body.data.items.every((s: { distanceMeters: unknown }) => s.distanceMeters === null)).toBe(true);
  });
  it.each(['recommended', 'favorites', 'distance', 'latest'])('%s 与区域、关键词和拍摄条件共同生效', async sort => {
    const query = { sort, ...location, province: '测试省', keyword: city, bestTimes: 'night', bestSeasons: 'winter', focalLengths: 'tele', difficulties: '1' };
    expect((await feed(query).expect(200)).body.data.items).toHaveLength(spots.length);
    expect((await feed({ ...query, bestTimes: 'sunrise' }).expect(200)).body.data.items).toEqual([]);
    expect((await feed({ ...query, province: '不匹配省' }).expect(200)).body.data.items).toEqual([]);
    expect((await feed({ ...query, keyword: '不存在的作品' }).expect(200)).body.data.items).toEqual([]);
  });
  it.each([
    { sort: 'distance' }, { sort: 'unknown' }, { sort: 'recommended', order: 'asc' },
    { sort: 'distance', viewerLat: '31' }, { sort: 'distance', viewerLat: '91', viewerLng: '121' },
    { sort: 'recommended', viewerLat: '0', viewerLng: '181' }, { sort: 'distance', viewerLat: '', viewerLng: '' },
    { sort: 'latest', order: 'invalid' }, { order: 'asc' },
  ])('无定位距离排序或畸形参数返回可读 400 %j', async query => {
    const res = await feed(query).expect(400);
    expect(res.body.error.message).toBeTruthy();
  });
  it('零坐标为有效定位，默认距离从近到远', async () => {
    const res = await feed({ sort: 'distance', viewerLat: '0', viewerLng: '0' }).expect(200);
    const d = res.body.data.items.map((s: { distanceMeters: number }) => s.distanceMeters);
    expect(d).toEqual(d.slice().sort((a: number, b: number) => a - b));
  });
  it('切换排序、方向、条件和位置拒绝上一列表的游标', async () => {
    const res = await feed({ sort: 'recommended', ...location, limit: '1' }).expect(200);
    const cursor = res.body.data.nextCursor;
    for (const changed of [{ sort: 'favorites' }, { city: 'other' }, { keyword: 'test' }, { viewerLat: '30' }]) {
      await feed({ sort: 'recommended', ...location, cursor, ...changed }).expect(400);
    }
    const ascending = await feed({ sort: 'favorites', order: 'asc', limit: '1' }).expect(200);
    await feed({ sort: 'favorites', order: 'desc', cursor: ascending.body.data.nextCursor }).expect(400);
  });
  it('搜索不覆盖显式时间排序，并保留旧客户端默认行为', async () => {
    const old = await feed({ keyword: city }).expect(200);
    expect(old.body.data.items[0].id).toBe(spots[0].id);
    const explicit = await feed({ sort: 'latest', keyword: city }).expect(200);
    expect(explicit.body.data.items[0].id).toBe(spots[5].id);
  });
  it('收藏变动后刷新立即更新排序', async () => {
    const target = spots[3];
    await db.query('INSERT INTO spot_favorites(user_id,spot_id) SELECT unnest($1::uuid[]), $2', [users.slice(0, 20), target.id]);
    try {
      const res = await feed({ sort: 'favorites' }).expect(200);
      expect(res.body.data.items[1]).toMatchObject({ id: target.id, favoriteCount: 20 });
    } finally { await db.query('DELETE FROM spot_favorites WHERE spot_id=$1', [target.id]); }
  });
});

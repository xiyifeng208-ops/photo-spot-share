import { WeatherService } from './weather.service';
import { loadConfig } from '../config/configuration';
import { normalizeCurrent, normalizeForecast, shootingHints, reportTime } from './weather-data';
import { parseShootingDate } from '../shooting-times/solar-calculator';
const today=()=>parseShootingDate(undefined);
const nowText=()=>new Date(Date.now()+8*3600000).toISOString().slice(0,19).replace('T',' ');
const cast=()=>({date:today(),dayweather:'晴',nightweather:'阴',daytemp:'26',nighttemp:'18',daypower:'3',nightpower:'3'});
function harness(key='fake-test-key') {
 const db={queryOne:jest.fn(async()=>({lat:31.2,lng:121.5,focal_length:'tele',difficulty:2}))};
 const geo={reverse:jest.fn(async()=>({adcode:'310101'}))};
 return {service:new WeatherService(loadConfig({AMAP_KEY:key}),db as never,geo as never),db,geo};
}
function mockFetch(fail?:'base'|'all'|'both',report=nowText()) {
 return jest.spyOn(global,'fetch').mockImplementation(async input=>{
  const kind=new URL(String(input)).searchParams.get('extensions');
  if(fail==='both'||fail===kind)throw new Error('upstream secret must not escape');
  return {ok:true,json:async()=>kind==='base'
   ?{status:'1',lives:[{adcode:'310101',city:'黄浦区',weather:'小雨',temperature:'0',humidity:'90',windpower:'5',reporttime:report}]}
   :{status:'1',forecasts:[{adcode:'310101',city:'黄浦区',reporttime:report,casts:[cast()]}]}} as Response;
 });
}
describe('天气与拍摄提示',()=>{
 afterEach(()=>jest.restoreAllMocks());
 it('缺Key降级且无外部请求',async()=>{const {service,geo}=harness('');const r=await service.getForSpot('id');expect(r.status).toBe('unconfigured');expect(r.hints).toEqual([]);expect(geo.reverse).not.toHaveBeenCalled();});
 it('非公开机位不可查询天气',async()=>{const {service,db,geo}=harness();db.queryOne.mockResolvedValue(null as never);await expect(service.getForSpot('id')).rejects.toThrow();expect(geo.reverse).not.toHaveBeenCalled();});
 it('并发合并、缓存以及公开状态复核',async()=>{
  const fetch=mockFetch(),{service,db}=harness();const r=await Promise.all([service.getForSpot('a'),service.getForSpot('b')]);
  expect(fetch).toHaveBeenCalledTimes(2);expect(r[0].current?.temperature).toBe(0);expect(r[0].hints.length).toBeGreaterThan(0);
  await service.getForSpot('c');expect(fetch).toHaveBeenCalledTimes(2);expect(db.queryOne).toHaveBeenCalledTimes(3);
  for(const [url,opts] of fetch.mock.calls){expect(String(url)).toContain('city=310101');expect(opts?.signal).toBeDefined();}
 });
 it.each(['base','all'] as const)('单个 %s 失败保留可用部分',async failed=>{mockFetch(failed);const r=await harness().service.getForSpot('id');expect(r.status).toBe('partial');expect(r.warnings).toHaveLength(1);expect(failed==='base'?r.forecast.length:r.current).toBeTruthy();});
 it('全失败不伪造数据且不泄漏Key',async()=>{mockFetch('both');const r=await harness().service.getForSpot('id');expect(r.status).toBe('unavailable');expect(r.hints).toEqual([]);expect(JSON.stringify(r)).not.toMatch(/secret|fake-test-key/);});
 it('无预报的日期不套用今天的数据',async()=>{mockFetch();const r=await harness().service.getForSpot('id','2000-01-01');expect(r.hints).toEqual([]);expect(r.selectedForecast).toBeNull();});
 it('过期实况预报不生成提示',async()=>{mockFetch(undefined,'2000-01-01 00:00:00');const r=await harness().service.getForSpot('id');expect(r.current?.stale).toBe(true);expect(r.forecastStale).toBe(true);expect(r.hints).toEqual([]);});
 it.each(['2026-02-30','',['2026-01-01']])('无效日期 %j',async date=>{await expect(harness().service.getForSpot('id',date)).rejects.toThrow();});
 it('空值不变成0，非法日期被舍弃',()=>{
  expect(normalizeCurrent({weather:'晴',temperature:'',humidity:'N/A'})?.temperature).toBeNull();
  expect(normalizeCurrent({weather:'晴',temperature:[],humidity:'101'})?.humidity).toBeNull();
  expect(normalizeForecast([{...cast(),date:'2026-02-30'}])).toEqual([]);expect(reportTime('2026-02-30 00:00:00')).toBeNull();
 });
 it('雨雪大风低温与到达难度产生具体提示',()=>{const s=shootingHints('小雨',['5-6'],[-2],'tele',2).join('');for(const word of ['防水','风力','结冰','路线'])expect(s).toContain(word);expect(shootingHints('晴',['3'],[20],null,1).join('')).not.toMatch(/一定|保证|最佳/);});
});

@echo off
chcp 65001 >nul
setlocal
set "PROJECT_ROOT=%~dp0"
cd /d "%PROJECT_ROOT%"
if not exist "api\package.json" goto :missing_project
where node.exe >nul 2>&1
if errorlevel 1 goto :missing_node
where pnpm.cmd >nul 2>&1
if errorlevel 1 goto :missing_pnpm
where docker.exe >nul 2>&1
if errorlevel 1 goto :missing_docker
docker info >nul 2>&1
if errorlevel 1 goto :missing_docker
netstat -ano | findstr /R /C:":3000 .*LISTENING" >nul 2>&1
if not errorlevel 1 goto :port_used

echo [1/4] 启动数据库，保留已有数据...
docker container inspect spot-postgres >nul 2>&1
if errorlevel 1 goto :create_database
docker start spot-postgres
if errorlevel 1 goto :failed
goto :wait_database
:create_database
docker compose -f "%PROJECT_ROOT%deploy\docker-compose.yml" up -d --wait postgres
if errorlevel 1 goto :failed
:wait_database
set /a DB_ATTEMPTS=0
:check_database
docker exec spot-postgres pg_isready -U spot -d spot >nul 2>&1
if not errorlevel 1 goto :install
set /a DB_ATTEMPTS+=1
if %DB_ATTEMPTS% GEQ 30 goto :database_failed
timeout /t 2 /nobreak >nul
goto :check_database

:install
cd /d "%PROJECT_ROOT%api"
if not exist ".env" if not exist ".env.local" copy /y ".env.example" ".env" >nul
echo [2/4] 安装或检查后端依赖...
call pnpm.cmd install --frozen-lockfile
if errorlevel 1 goto :failed
echo [3/4] 执行数据库增量迁移...
call pnpm.cmd migrate
if errorlevel 1 goto :failed
echo [4/4] 启动后端，请保持窗口打开。
echo 健康检查：http://127.0.0.1:3000/health
echo 天气 Key 请填写在 api\.env 的 AMAP_KEY，然后重启后端。
call pnpm.cmd start:dev
if errorlevel 1 goto :failed
exit /b 0

:missing_project
echo 项目文件不完整。请完整解压，确认本文件与 api 文件夹在同一级。
goto :failed
:missing_node
echo 未找到 Node.js。安装 Node.js 22 或 24 后重新打开本文件。
goto :failed
:missing_pnpm
echo 未找到 pnpm.cmd。请在终端执行 npm.cmd install -g pnpm@9.15.9 后重试。
goto :failed
:missing_docker
echo 请先打开 Docker Desktop，等待 Engine running 后重试。
goto :failed
:port_used
echo 端口 3000 已被占用。请在旧后端窗口按 Ctrl+C 停止后重试。
echo 本脚本不会自动终止已有程序。
goto :failed
:database_failed
echo 数据库未就绪，请在 Docker Desktop 检查 spot-postgres 的日志。
:failed
echo 启动未完成。请保留上面的错误信息；不要删除数据库或运行重置命令。
pause
exit /b 1

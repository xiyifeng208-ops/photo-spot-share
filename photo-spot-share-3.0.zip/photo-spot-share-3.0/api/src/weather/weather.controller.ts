import { Controller, Get, Param, ParseUUIDPipe, Query } from '@nestjs/common';
import { Public } from '../common/guards/jwt-auth.guard';
import { RateLimit } from '../common/guards/rate-limit.guard';
import { WeatherService } from './weather.service';
@Public()
@Controller('spots')
export class WeatherController {
  constructor(private readonly weather: WeatherService) {}
  @Get(':id/weather')
  @RateLimit({ scope: 'user-and-route', limit: 60, windowMs: 60000 })
  get(@Param('id',new ParseUUIDPipe({errorHttpStatusCode:404})) id: string, @Query('date') date?: unknown) {
    return this.weather.getForSpot(id,date);
  }
}

import { randomUUID } from 'node:crypto';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { Client } from 'pg';
import { AppModule } from '../app.module';
import { AllExceptionsFilter } from '../common/filters/all-exceptions.filter';
import { ResponseInterceptor } from '../common/interceptors/response.interceptor';
import { runMigrations } from '../database/migration-runner';
import { defaultPreferences } from './recommendation-profile';
const url = process.env.TEST_DATABASE_URL;
(url ? describe : describe.skip)('个性化推荐 HTTP 与数据库流程', () => {
  let app: INestApplication, db: Client;
  const city = 'recommend-' + randomUUID();
  const ids = Array.from({length:5},()=>randomUUID());
  let a: {token:string; user:{id:string}}, b: typeof a;
  beforeAll(async () => {
    Object.assign(process.env,{NODE_ENV:'test',DATABASE_URL:url,AUTH_DEV_MODE:'true',CONTENT_CHECK_ENABLED:'false',AMAP_KEY:''});
    await runMigrations(url!,()=>undefined);
    db = new Client({connectionString:url}); await db.connect();
    const module = await Test.createTestingModule({imports:[AppModule]}).compile();
    app = module.createNestApplication(); app.setGlobalPrefix('api/v1');
    app.useGlobalPipes(new ValidationPipe({whitelist:true,transform:true}));
    app.useGlobalFilters(new AllExceptionsFilter()); app.useGlobalInterceptors(new ResponseInterceptor()); await app.init();
    const login = async () => (await request(app.getHttpServer()).post('/api/v1/auth/wx-login').send({code:'dev:'+randomUUID()}).expect(201)).body.data;
    a = await login(); b = await login();
    for (let i=0;i<ids.length;i++) await db.query(`INSERT INTO spots(id,user_id,title,city,province,lat,lng,location,best_times,best_seasons,focal_length,difficulty,status,created_at)
      VALUES($1,$2,$3,$3,'测试省',31.23,121.47,ST_SetSRID(ST_MakePoint(121.47,31.23),4326)::geography,$4,'{winter}','tele',1,$5,'2026-01-01T00:00:00.123456Z')`,
      [ids[i],a.user.id,city,i%2 ? ['sunrise'] : ['night'],i===4?'hidden':'active']);
  },60000);
  afterAll(async () => { await app?.close(); if(db) { await db.query('DELETE FROM users WHERE id=ANY($1::uuid[])',[[a?.user.id,b?.user.id].filter(Boolean)]); await db.end(); } });
  const api = () => request(app.getHttpServer());
  const feed = (who?: typeof a, extra: Record<string,string>={}) => {
    let r = api().get('/api/v1/spots/feed').query({city,sort:'recommended',...extra});
    if(who) r=r.set('Authorization','Bearer '+who.token); return r;
  };
  const prefs = (who: typeof a, data={}) => api().put('/api/v1/recommendations/preferences').set('Authorization','Bearer '+who.token).send({...defaultPreferences(),useFavorites:false,...data});
  beforeEach(async () => {
    await db.query('DELETE FROM spot_favorites WHERE user_id=ANY($1::uuid[])',[[a.user.id,b.user.id]]);
    await db.query('DELETE FROM spot_dismissals WHERE user_id=ANY($1::uuid[])',[[a.user.id,b.user.id]]);
    await prefs(a).expect(200); await prefs(b).expect(200);
  });
  it('未登录可浏览但不能读取修改个人设置', async () => {
    await feed().expect(200); await api().get('/api/v1/recommendations/preferences').expect(401);
    await api().put('/api/v1/recommendations/preferences').send(defaultPreferences()).expect(401);
  });
  it('冷启动与匿名排序一致', async () => {
    const cold=(await feed(a).expect(200)).body.data, anon=(await feed().expect(200)).body.data;
    expect(cold.items.map((i:any)=>i.id)).toEqual(anon.items.map((i:any)=>i.id)); expect(cold.recommendation.personalized).toBe(false);
  });
  it('不同账号推荐不同，理由基于真实标签', async () => {
    await prefs(a,{bestTimes:['night']}); await prefs(b,{bestTimes:['sunrise']});
    const ar=(await feed(a).expect(200)).body.data, br=(await feed(b).expect(200)).body.data;
    expect([ids[0],ids[2]]).toContain(ar.items[0].id); expect([ids[1],ids[3]]).toContain(br.items[0].id);
    expect(ar.items[0].recommendationReasons[0]).toContain('夜景'); expect(br.items[0].recommendationReasons[0]).toContain('日出');
    expect(ar.recommendation.personalized).toBe(true);
  });
  it('收藏学习、取消收藏及关闭学习生效', async () => {
    await prefs(a,{useFavorites:true});
    await api().put(`/api/v1/spots/${ids[1]}/favorite`).set('Authorization','Bearer '+a.token).expect(200);
    expect((await feed(a).expect(200)).body.data.items[0].recommendationReasons[0]).toContain('收藏');
    await prefs(a,{useFavorites:false}); expect((await feed(a)).body.data.recommendation.personalized).toBe(false);
    await api().delete(`/api/v1/spots/${ids[1]}/favorite`).set('Authorization','Bearer '+a.token).expect(200);
    await prefs(a,{useFavorites:true}); expect((await feed(a)).body.data.recommendation.personalized).toBe(false);
  });
  it('全局排序分页无重复，保留筛选且隐藏内容不出现', async () => {
    await prefs(a,{bestTimes:['night']});
    const full=(await feed(a).expect(200)).body.data.items.map((i:any)=>i.id);
    const idsSeen:string[]=[]; let cursor='';
    do { const data=(await feed(a,{limit:'1',...(cursor?{cursor}:{})}).expect(200)).body.data;
      idsSeen.push(...data.items.map((i:any)=>i.id)); cursor=data.nextCursor; } while(cursor && idsSeen.length<10);
    expect(idsSeen).toEqual(full); expect(idsSeen).not.toContain(ids[4]);
    const filtered=(await feed(a,{bestTimes:'sunrise'}).expect(200)).body.data.items;
    expect(filtered).toHaveLength(2); expect(filtered.every((i:any)=>i.bestTimes.includes('sunrise'))).toBe(true);
  });
  it('偏好、账号、不感兴趣变化后旧游标失效', async () => {
    await prefs(a,{bestTimes:['night']}); const cursor=(await feed(a,{limit:'1'})).body.data.nextCursor;
    await feed(b,{cursor}).expect(400); await prefs(a,{bestTimes:['sunrise']}); await feed(a,{cursor}).expect(400);
    const next=(await feed(a,{limit:'1'})).body.data.nextCursor;
    await api().put(`/api/v1/recommendations/dismissed/${ids[0]}`).set('Authorization','Bearer '+a.token).expect(200);
    await feed(a,{cursor:next}).expect(400);
  });
  it('不感兴趣只影响本人综合推荐并可撤销', async () => {
    await api().put(`/api/v1/recommendations/dismissed/${ids[0]}`).set('Authorization','Bearer '+a.token).expect(200);
    expect((await feed(a)).body.data.items.map((i:any)=>i.id)).not.toContain(ids[0]);
    expect((await feed(b)).body.data.items.map((i:any)=>i.id)).toContain(ids[0]);
    expect((await feed(a,{sort:'latest'})).body.data.items.map((i:any)=>i.id)).toContain(ids[0]);
    await api().delete(`/api/v1/recommendations/dismissed/${ids[0]}`).set('Authorization','Bearer '+a.token).expect(200);
    expect((await feed(a)).body.data.items.map((i:any)=>i.id)).toContain(ids[0]);
  });
  it('关闭个性化生效，重置保留收藏', async () => {
    await prefs(a,{bestTimes:['night'],enabled:false}); expect((await feed(a)).body.data.recommendation.personalized).toBe(false);
    await api().put(`/api/v1/spots/${ids[0]}/favorite`).set('Authorization','Bearer '+a.token);
    const result=await api().post('/api/v1/recommendations/reset').set('Authorization','Bearer '+a.token).expect(201);
    expect(result.body.data.bestTimes).toEqual([]); expect(result.body.data.useFavorites).toBe(false);
    expect((await db.query('SELECT * FROM spot_favorites WHERE user_id=$1',[a.user.id])).rowCount).toBe(1);
  });
  it('非法枚举重复标签返回400，非公开内容不能标记', async () => {
    await prefs(a,{bestTimes:['invented']}).expect(400); await prefs(a,{difficulties:[1,1]}).expect(400);
    await api().put(`/api/v1/recommendations/dismissed/${ids[4]}`).set('Authorization','Bearer '+a.token).expect(404);
  });
  it('天气缺Key降级不增加浏览量，隐藏机位404', async () => {
    const before=await db.query('SELECT view_count FROM spots WHERE id=$1',[ids[0]]);
    expect((await api().get(`/api/v1/spots/${ids[0]}/weather`).expect(200)).body.data.status).toBe('unconfigured');
    expect((await db.query('SELECT view_count FROM spots WHERE id=$1',[ids[0]])).rows[0]).toEqual(before.rows[0]);
    await api().get(`/api/v1/spots/${ids[4]}/weather`).expect(404);
    await api().get(`/api/v1/spots/${ids[0]}/weather?date=2026-02-30`).expect(400);
  });
});

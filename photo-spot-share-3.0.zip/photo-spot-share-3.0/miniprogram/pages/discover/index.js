const { request } = require('../../utils/request');
const auth = require('../../utils/auth');
const geo = require('../../utils/geo');
const format = require('../../utils/format');
const { provinces } = require('../../data/cities');
const PAGE_SIZE = 10;
const SEARCH_DELAY_MS = 300;
const SORT_OPTIONS = [
  { value: 'recommended', label: '综合' },
  { value: 'favorites', label: '收藏量' },
  { value: 'distance', label: '距离' },
  { value: 'latest', label: '时间' }
];

function validLocation(location) {
  if (!location || !Number.isFinite(location.latitude) || !Number.isFinite(location.longitude)
    || Math.abs(location.latitude) > 90 || Math.abs(location.longitude) > 180) return null;
  return { latitude: location.latitude, longitude: location.longitude };
}

function sortSummary(sort, order, viewer) {
  if (sort === 'recommended') return viewer
    ? '综合：收藏 50% · 距离 30% · 新鲜度 20%'
    : '未获取定位，综合排序暂按收藏和新鲜度衡量';
  if (sort === 'favorites') return order === 'desc' ? '收藏量从高到低 · 再次点击可反向' : '收藏量从低到高 · 再次点击可反向';
  if (sort === 'distance') return order === 'asc' ? '距你从近到远 · 再次点击可反向' : '距你从远到近 · 再次点击可反向';
  return order === 'desc' ? '发布时间从新到旧 · 再次点击可反向' : '发布时间从旧到新 · 再次点击可反向';
}
const CONDITION_GROUPS = [
  { field: 'bestTimes', label: '拍摄时段', options: format.BEST_TIME_OPTIONS },
  { field: 'bestSeasons', label: '推荐季节', options: format.SEASON_OPTIONS },
  { field: 'focalLengths', label: '推荐焦段', options: format.FOCAL_LENGTH_OPTIONS },
  { field: 'difficulties', label: '到达难度', options: format.DIFFICULTY_OPTIONS }
];

function emptyConditions() {
  return { bestTimes: [], bestSeasons: [], focalLengths: [], difficulties: [] };
}

function copyConditions(filters) {
  return Object.fromEntries(CONDITION_GROUPS.map(group => [group.field, filters[group.field].slice()]));
}

function conditionGroups(filters) {
  return CONDITION_GROUPS.map(group => ({
    field: group.field, label: group.label,
    options: group.options.map(option => ({ ...option, value: String(option.value),
      selected: filters[group.field].includes(String(option.value)) }))
  }));
}

function conditionSummary(filters) {
  return CONDITION_GROUPS.flatMap(group => group.options
    .filter(option => filters[group.field].includes(String(option.value)))
    .map(option => ({ key: `${group.field}:${option.value}`, field: group.field,
      value: String(option.value), label: option.label })));
}

function decorate(spot) {
  return { ...spot, favoriteCount: Number.isSafeInteger(spot.favoriteCount) && spot.favoriteCount >= 0 ? spot.favoriteCount : 0,
    distanceText: format.formatDistance(spot.distanceMeters),
    createdText: format.formatDate(spot.createdAt), tagList: format.buildTags(spot) };
}

Page({
  data: {
    province: '', city: '', district: '', cityLabel: '全部城市',
    keywordInput: '', keyword: '', sortHint: '', cityPickerOpen: false,
    sort: 'recommended', sortOrder: 'desc', sortOptions: SORT_OPTIONS,
    locatingSort: false, sortLocationError: '', recommendation: null, dismissPending: false, undoDismissId: '',
    provinces: provinces.map(({ code, name }) => ({ code, name })),
    pickerProvinceCode: provinces[0].code, pickerCities: provinces[0].cities,
    selectedCityCode: '',
    shootingPickerOpen: false,
    shootingFilters: emptyConditions(), draftFilters: emptyConditions(),
    filterGroups: conditionGroups(emptyConditions()), selectedConditions: [],
    spots: [], cursor: '', loading: false, finished: false, error: '', located: false
  },

  onLoad() {
    this.queryRevision = 0;
    this.sortActionRevision = 0;
    this.unloaded = false;
    this.userPickedFilter = false;
    this.visible = false;
    this.hasShown = false;
    this.favoriteCountRevision = this.currentFavoriteRevision();
    this.reload();
    this.bootstrapCity();
  },

  currentFavoriteRevision() {
    const app = getApp();
    return (app && app.globalData && app.globalData.favoriteCountRevision) || 0;
  },
  onShow() {
    this.visible = true;
    if (this.undoDismissOwner !== this.recommendationUserId()) this.setData({ undoDismissId: '' });
    const needsRefresh = this.hasShown || this.favoriteCountRevision !== this.currentFavoriteRevision();
    this.hasShown = true;
    this.favoriteCountRevision = this.currentFavoriteRevision();
    // Counts may also have changed on another device. Return to the first page,
    // retaining the entire current city/keyword/condition selection.
    if (needsRefresh && !this.unloaded) {
      this.setData({ keyword: this.data.keywordInput.trim() });
      return this.reload();
    }
  },
  onHide() { this.visible = false; },
  onFavoriteCountsChanged() {
    if (!this.visible || this.unloaded || this.favoriteCountRevision === this.currentFavoriteRevision()) return;
    this.favoriteCountRevision = this.currentFavoriteRevision();
    this.setData({ keyword: this.data.keywordInput.trim() });
    return this.reload();
  },

  onUnload() {
    this.unloaded = true;
    this.visible = false;
    this.queryRevision += 1;
    clearTimeout(this.searchTimer);
  },

  onPullDownRefresh() {
    this.reload().finally(() => wx.stopPullDownRefresh());
  },

  onReachBottom() {
    if (!this.data.error) this.loadMore();
  },

  async bootstrapCity() {
    const beforeLogin = this.recommendationUserId();
    await auth.ensureLogin().catch(() => null);
    if (!this.unloaded && beforeLogin !== this.recommendationUserId()) this.reload();
    if (this.unloaded || this.userPickedFilter) return;
    const location = await geo.getUserLocation({ highAccuracy: false, timeoutMs: 3000 });
    if (!validLocation(location) || this.unloaded || this.userPickedFilter) return;
    this.currentLocation = validLocation(location);
    const meta = await request({
      url: `/geo/reverse?lng=${location.longitude}&lat=${location.latitude}`
    }).catch(() => null);
    if (this.unloaded || this.userPickedFilter) return;
    // Distance ranking does not depend on reverse geocoding or an AMAP key.
    if (!meta) return this.reload();
    const province = provinces.find(p => p.name === meta.province);
    const city = province && province.cities.find(c =>
      c.name === (c.field === 'district' ? meta.district : meta.city));
    if (city) {
      this.setRegion(province, city);
      this.setData({ located: true });
      this.reload();
    } else if (meta.city) {
      this.setData({ province: meta.province || '', city: meta.city, cityLabel: meta.city, located: true });
      this.reload();
    } else {
      this.reload();
    }
  },

  async onSortTap(event) {
    const sort = event.currentTarget.dataset.sort;
    if (!SORT_OPTIONS.some(option => option.value === sort) || this.unloaded) return;
    this.userPickedFilter = true;
    const action = ++this.sortActionRevision;
    const revision = this.queryRevision;
    this.setData({ cityPickerOpen: false, shootingPickerOpen: false, locatingSort: false, sortLocationError: '' });
    let viewer = this.availableLocation();
    if (sort === 'distance' && !viewer) {
      this.setData({ locatingSort: true });
      viewer = validLocation(await geo.getUserLocation({ highAccuracy: false, timeoutMs: 3000 }).catch(() => null));
      if (this.unloaded || action !== this.sortActionRevision || revision !== this.queryRevision) return;
      this.setData({ locatingSort: false });
      if (!viewer) {
        this.setData({ sortLocationError: '未获取到位置，已保留原排序。请开启定位后重试。' });
        return;
      }
      this.currentLocation = viewer;
    }
    const sortOrder = sort === 'recommended' ? 'desc'
      : sort === this.data.sort ? (this.data.sortOrder === 'asc' ? 'desc' : 'asc')
        : sort === 'distance' ? 'asc' : 'desc';
    this.setData({ sort, sortOrder });
    return this.reload();
  },

  async onLocationSettings() {
    const action = ++this.sortActionRevision;
    const revision = this.queryRevision;
    const opened = await geo.openLocationSetting();
    if (!opened || this.unloaded || action !== this.sortActionRevision || revision !== this.queryRevision) return;
    return this.onSortTap({ currentTarget: { dataset: { sort: 'distance' } } });
  },

  availableLocation() {
    const app = getApp();
    return validLocation(app && app.globalData && app.globalData.lastLocation) || validLocation(this.currentLocation);
  },

  // Invalidate on input, before debounce: older results must never win.
  resetQuery() {
    this.queryRevision = (this.queryRevision || 0) + 1;
    this.sortActionRevision = (this.sortActionRevision || 0) + 1;
    // Freeze coordinates for this pagination sequence, even if another page locates again.
    this.feedViewer = this.availableLocation();
    this.setData({ spots: [], cursor: '', finished: false, loading: true, error: '', locatingSort: false, sortLocationError: '', recommendation: null });
    return this.queryRevision;
  },

  reload() {
    clearTimeout(this.searchTimer);
    this.favoriteCountRevision = this.currentFavoriteRevision();
    return this.fetchPage(this.resetQuery(), '');
  },

  loadMore() {
    if (this.data.loading || this.data.finished || this.unloaded) return Promise.resolve();
    return this.fetchPage(this.queryRevision, this.data.cursor);
  },

  async fetchPage(revision, cursor) {
    if (this.unloaded || revision !== this.queryRevision) return;
    const viewer = this.feedViewer;
    const ownerId = this.recommendationUserId();
    this.setData({ loading: true, error: '', sortHint: sortSummary(this.data.sort, this.data.sortOrder, viewer) });
    const query = [`limit=${PAGE_SIZE}`, `sort=${this.data.sort}`, `order=${this.data.sortOrder}`];
    for (const field of ['province', 'city', 'district', 'keyword']) {
      if (this.data[field]) query.push(`${field}=${encodeURIComponent(this.data[field])}`);
    }
    for (const group of CONDITION_GROUPS) {
      const values = this.data.shootingFilters[group.field];
      if (values.length) query.push(`${group.field}=${encodeURIComponent(values.join(','))}`);
    }
    if (cursor) query.push(`cursor=${encodeURIComponent(cursor)}`);
    if (viewer) query.push(`viewerLat=${viewer.latitude}`, `viewerLng=${viewer.longitude}`);
    try {
      const result = await request({ url: `/spots/feed?${query.join('&')}` });
      if (this.unloaded || revision !== this.queryRevision) return;
      if (ownerId !== this.recommendationUserId()) return this.reload();
      // Counts can change between cursor pages. Deduplicate repeated IDs but
      // never sort a partial page: keep the server's first-seen order/cursor.
      const combined = (cursor ? this.data.spots : []).concat(result.items.map(decorate));
      const byId = new Map(combined.map(item => [item.id, item]));
      this.setData({
        spots: [...byId.values()],
        recommendation: this.data.sort === 'recommended' ? (result.recommendation || null) : null,
        cursor: result.nextCursor || '', finished: !result.nextCursor, loading: false, error: ''
      });
    } catch (error) {
      if (this.unloaded || revision !== this.queryRevision) return;
      if (cursor && error.statusCode === 400 && /分页游标/.test(error.message || '')) return this.reload();
      this.setData({ loading: false, error: error.message || '作品加载失败，请重试' });
    }
  },

  recommendationUserId() {
    const user = typeof auth.currentUser === 'function' ? auth.currentUser() : null;
    return user && user.id || null;
  },
  onPreferencesTap() { wx.navigateTo({ url: '/pages/preferences/index' }); },
  async onDismissTap(event) {
    const id = event.currentTarget.dataset.id;
    const userId = this.recommendationUserId();
    if (!id || !userId || this.data.dismissPending || !this.data.recommendation || !this.data.recommendation.canDismiss) return;
    const revision = this.queryRevision;
    this.setData({ dismissPending: true });
    try {
      await request({ url: `/recommendations/dismissed/${id}`, method: 'PUT', boundUserId: userId });
      if (this.unloaded || userId !== this.recommendationUserId()) return;
      this.undoDismissOwner = userId;
      this.setData({ undoDismissId: id });
      if (revision === this.queryRevision && this.data.sort === 'recommended') await this.reload();
    } catch (error) {
      if (!this.unloaded) wx.showToast({ title: error.message || '操作失败，请重试', icon: 'none' });
    } finally {
      if (!this.unloaded) this.setData({ dismissPending: false });
    }
  },
  async onUndoDismiss() {
    const id = this.data.undoDismissId, userId = this.recommendationUserId();
    if (!id || !userId || userId !== this.undoDismissOwner || this.data.dismissPending) return;
    const revision = this.queryRevision;
    this.setData({ dismissPending: true });
    try {
      await request({ url: `/recommendations/dismissed/${id}`, method: 'DELETE', boundUserId: userId });
      if (this.unloaded || userId !== this.recommendationUserId()) return;
      this.setData({ undoDismissId: '' });
      if (revision === this.queryRevision && this.data.sort === 'recommended') await this.reload();
    } catch (error) {
      if (!this.unloaded) wx.showToast({ title: error.message || '恢复失败，请重试', icon: 'none' });
    } finally {
      if (!this.unloaded) this.setData({ dismissPending: false });
    }
  },

  onRetry() {
    return this.data.spots.length ? this.loadMore() : this.reload();
  },

  onToggleCity() {
    this.userPickedFilter = true;
    this.onCloseShootingPicker();
    this.setData({ cityPickerOpen: !this.data.cityPickerOpen });
  },

  onCloseCityPicker() { this.setData({ cityPickerOpen: false }); },
  onPanelTouchMove() {},

  onOpenShootingPicker() {
    this.userPickedFilter = true;
    if (wx.hideKeyboard) wx.hideKeyboard();
    const draftFilters = copyConditions(this.data.shootingFilters);
    this.setData({ shootingPickerOpen: true, cityPickerOpen: false, draftFilters,
      filterGroups: conditionGroups(draftFilters) });
  },

  onCloseShootingPicker() {
    const draftFilters = copyConditions(this.data.shootingFilters);
    this.setData({ shootingPickerOpen: false, draftFilters, filterGroups: conditionGroups(draftFilters) });
  },

  onDraftConditionTap(event) {
    const { field, value } = event.currentTarget.dataset;
    const group = CONDITION_GROUPS.find(item => item.field === field);
    if (!group || !group.options.some(option => String(option.value) === String(value))) return;
    const draftFilters = copyConditions(this.data.draftFilters);
    const values = draftFilters[field];
    const selected = values.includes(String(value))
      ? values.filter(item => item !== String(value)) : values.concat(String(value));
    // Keep option order stable regardless of tap order.
    draftFilters[field] = group.options.map(option => String(option.value)).filter(item => selected.includes(item));
    this.setData({ draftFilters, filterGroups: conditionGroups(draftFilters) });
  },

  onResetDraftConditions() {
    const draftFilters = emptyConditions();
    this.setData({ draftFilters, filterGroups: conditionGroups(draftFilters) });
  },

  applyShootingFilters(filters) {
    this.userPickedFilter = true;
    const shootingFilters = copyConditions(filters);
    this.setData({ shootingFilters, selectedConditions: conditionSummary(shootingFilters),
      shootingPickerOpen: false, cityPickerOpen: false });
    return this.reload();
  },

  onConfirmConditions() { return this.applyShootingFilters(this.data.draftFilters); },

  onRemoveCondition(event) {
    const { field, value } = event.currentTarget.dataset;
    if (!CONDITION_GROUPS.some(group => group.field === field)) return;
    const filters = copyConditions(this.data.shootingFilters);
    filters[field] = filters[field].filter(item => item !== String(value));
    return this.applyShootingFilters(filters);
  },

  onClearConditions() { return this.applyShootingFilters(emptyConditions()); },

  onSelectProvince(event) {
    const province = provinces.find(p => p.code === event.currentTarget.dataset.code);
    if (!province) return;
    this.userPickedFilter = true;
    this.setData({ pickerProvinceCode: province.code, pickerCities: province.cities });
  },

  setRegion(province, city) {
    this.setData({
      province: province.name,
      city: city.field === 'city' ? city.name : '',
      district: city.field === 'district' ? city.name : '',
      cityLabel: city.name, pickerProvinceCode: province.code, pickerCities: province.cities,
      selectedCityCode: city.code, cityPickerOpen: false
    });
  },

  onSelectCity(event) {
    const province = provinces.find(p => p.code === this.data.pickerProvinceCode);
    const city = province && province.cities.find(c => c.code === event.currentTarget.dataset.code);
    if (!city) return;
    this.userPickedFilter = true;
    this.setRegion(province, city);
    return this.reload();
  },

  onSelectAllCities() {
    this.userPickedFilter = true;
    this.setData({ province: '', city: '', district: '', cityLabel: '全部城市', selectedCityCode: '', cityPickerOpen: false });
    return this.reload();
  },

  onSearchFocus() {
    this.userPickedFilter = true;
    this.onCloseCityPicker();
    this.onCloseShootingPicker();
  },

  onSearchInput(event) {
    this.userPickedFilter = true;
    const value = event.detail.value.slice(0, 100);
    const keyword = value.trim();
    this.setData({ keywordInput: value, cityPickerOpen: false });
    if (keyword === this.data.keyword) return;
    clearTimeout(this.searchTimer);
    this.setData({ keyword });
    const revision = this.resetQuery();
    if (!keyword) return this.fetchPage(revision, '');
    this.searchTimer = setTimeout(() => this.fetchPage(revision, ''), SEARCH_DELAY_MS);
  },

  onSearchConfirm() {
    this.userPickedFilter = true;
    this.setData({ keyword: this.data.keywordInput.trim(), cityPickerOpen: false });
    return this.reload();
  },

  onClearSearch() {
    this.userPickedFilter = true;
    this.setData({ keywordInput: '', keyword: '' });
    return this.reload();
  },

  onSpotTap(event) {
    wx.navigateTo({ url: `/pages/spot/detail?id=${event.currentTarget.dataset.id}` });
  },

  onCoverError(event) {
    const id = event.currentTarget.dataset.id;
    this.setData({ spots: this.data.spots.map(spot => spot.id === id ? { ...spot, coverFailed: true, coverUrl: '' } : spot) });
  },

  onRoutesTap() {
    this.setData({ cityPickerOpen: false, shootingPickerOpen: false });
    wx.navigateTo({ url: '/pages/routes/index' });
  },
  onCreateTap() { wx.navigateTo({ url: '/pages/spot/create' }); }
});

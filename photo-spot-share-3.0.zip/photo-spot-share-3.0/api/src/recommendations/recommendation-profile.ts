import { BEST_TIME_LABELS, SEASON_LABELS, FOCAL_LENGTH_LABELS, DIFFICULTY_LABELS } from '../common/enums';
import type { PreferencesDto } from './preferences.dto';

export interface PreferenceSpot {
  best_times: string[] | null;
  best_seasons: string[] | null;
  focal_length: string | null;
  difficulty: number | null;
}
export const GROUPS = [
  { key: 'time', field: 'bestTimes', labels: BEST_TIME_LABELS },
  { key: 'season', field: 'bestSeasons', labels: SEASON_LABELS },
  { key: 'focal', field: 'focalLengths', labels: FOCAL_LENGTH_LABELS },
  { key: 'difficulty', field: 'difficulties', labels: DIFFICULTY_LABELS },
] as const;
export interface InterestProfile {
  settings: PreferencesDto;
  weights: Record<string, number>;
  groupCount: number;
  favoriteSampleCount: number;
  learnedTags: string[];
}
export const defaultPreferences = (): PreferencesDto => ({
  enabled: true, useFavorites: true, bestTimes: [], bestSeasons: [], focalLengths: [], difficulties: [],
});
export function spotValues(spot: PreferenceSpot): Record<string, string[]> {
  return {
    time: spot.best_times || [], season: spot.best_seasons || [],
    focal: spot.focal_length ? [spot.focal_length] : [],
    difficulty: spot.difficulty === null ? [] : [String(spot.difficulty)],
  };
}
/** Explicit selections are stronger than inferred favorites; no viewing history is collected. */
export function buildInterestProfile(settings: PreferencesDto, favorites: PreferenceSpot[]): InterestProfile {
  const weights: Record<string, number> = {};
  const learnedTags: string[] = [];
  let groupCount = 0;
  for (const group of GROUPS) {
    const labels: Record<string, string> = group.labels;
    const explicit = new Set(settings[group.field].map(String));
    const counts: Record<string, number> = {};
    if (settings.useFavorites) {
      for (const spot of favorites) for (const value of new Set(spotValues(spot)[group.key])) {
        if (labels[value]) counts[value] = (counts[value] || 0) + 1;
      }
    }
    const max = Math.max(0, ...Object.values(counts));
    if (!explicit.size && !max) continue;
    groupCount++;
    for (const value of Object.keys(labels)) {
      const selected = explicit.has(value) ? 1 : 0;
      const inferred = max ? (counts[value] || 0) / max : 0;
      const weight = explicit.size && max ? 0.7 * selected + 0.3 * inferred : explicit.size ? selected : inferred;
      if (weight > 0) weights[`${group.key}:${value}`] = Number(weight.toFixed(6));
    }
    if (max) {
      const top = Object.keys(counts).sort((a, b) => counts[b] - counts[a] || a.localeCompare(b))[0];
      learnedTags.push(labels[top]);
    }
  }
  return { settings, weights, groupCount, favoriteSampleCount: favorites.length, learnedTags };
}
export function recommendationReasons(profile: InterestProfile, spot: PreferenceSpot): string[] {
  const matches: { score: number; text: string }[] = [];
  const values = spotValues(spot);
  for (const group of GROUPS) {
    const selected = new Set(profile.settings[group.field].map(String));
    const labels: Record<string, string> = group.labels;
    for (const value of values[group.key]) {
      const score = profile.weights[`${group.key}:${value}`] || 0;
      if (score > 0) matches.push({ score, text: selected.has(value)
        ? `符合你选择的「${labels[value]}」偏好` : `与你收藏的「${labels[value]}」机位相似` });
    }
  }
  return matches.sort((a, b) => b.score - a.score).slice(0, 2).map(item => item.text);
}

/** Weights are server-derived JSON; all values remain SQL parameters. Each group contributes at most 1. */
export const INTEREST_SQL = `(
  COALESCE((SELECT MAX(($16::jsonb ->> ('time:' || v))::double precision) FROM unnest(best_times) v), 0)
  + COALESCE((SELECT MAX(($16::jsonb ->> ('season:' || v))::double precision) FROM unnest(best_seasons) v), 0)
  + COALESCE(($16::jsonb ->> ('focal:' || focal_length))::double precision, 0)
  + COALESCE(($16::jsonb ->> ('difficulty:' || difficulty::text))::double precision, 0)
) / GREATEST($17::int, 1)`;

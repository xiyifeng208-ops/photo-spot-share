import { Injectable } from '@nestjs/common';
import { DatabaseService } from '../database/database.service';
import { AppException } from '../common/errors';
import { PreferencesDto } from './preferences.dto';
import { buildInterestProfile, defaultPreferences, type PreferenceSpot } from './recommendation-profile';

@Injectable()
export class RecommendationsService {
  constructor(private readonly db: DatabaseService) {}

  async profile(userId: string) {
    const row = await this.db.queryOne<{
      enabled: boolean; use_favorites: boolean; best_times: string[]; best_seasons: string[];
      focal_lengths: string[]; difficulties: number[];
    }>('SELECT * FROM user_recommendation_preferences WHERE user_id=$1', [userId]);
    const settings: PreferencesDto = row ? { enabled: row.enabled, useFavorites: row.use_favorites,
      bestTimes: row.best_times, bestSeasons: row.best_seasons, focalLengths: row.focal_lengths,
      difficulties: row.difficulties } : defaultPreferences();
    const favorites = settings.enabled && settings.useFavorites ? (await this.db.query<PreferenceSpot>(`
      SELECT s.best_times::text[], s.best_seasons::text[], s.focal_length, s.difficulty
      FROM spot_favorites f JOIN spots s ON s.id=f.spot_id
      WHERE f.user_id=$1 AND s.status='active'
      ORDER BY f.created_at DESC, f.spot_id DESC LIMIT 200`, [userId])).rows : [];
    const dismissed = (await this.db.query<{ spot_id: string }>(
      'SELECT spot_id FROM spot_dismissals WHERE user_id=$1 ORDER BY spot_id', [userId])).rows.map(r => r.spot_id);
    return { ...buildInterestProfile(settings, favorites), dismissed };
  }

  async getSettings(userId: string) {
    const profile = await this.profile(userId);
    return { ...profile.settings, learnedTags: profile.learnedTags,
      favoriteSampleCount: profile.favoriteSampleCount, dismissedCount: profile.dismissed.length };
  }

  async save(userId: string, dto: PreferencesDto) {
    await this.db.query(`INSERT INTO user_recommendation_preferences
      (user_id,enabled,use_favorites,best_times,best_seasons,focal_lengths,difficulties)
      VALUES($1,$2,$3,$4,$5,$6,$7) ON CONFLICT(user_id) DO UPDATE SET
      enabled=EXCLUDED.enabled,use_favorites=EXCLUDED.use_favorites,best_times=EXCLUDED.best_times,
      best_seasons=EXCLUDED.best_seasons,focal_lengths=EXCLUDED.focal_lengths,
      difficulties=EXCLUDED.difficulties,updated_at=now()`,
      [userId, dto.enabled, dto.useFavorites, [...dto.bestTimes].sort(), [...dto.bestSeasons].sort(),
        [...dto.focalLengths].sort(), [...dto.difficulties].sort()]);
    return this.getSettings(userId);
  }

  async dismiss(userId: string, spotId: string) {
    return this.db.withTransaction(async client => {
      const spot = await client.query("SELECT id FROM spots WHERE id=$1 AND status='active' FOR SHARE", [spotId]);
      if (!spot.rowCount) throw AppException.notFound('机位不存在或暂不可用');
      await client.query('INSERT INTO spot_dismissals(user_id,spot_id) VALUES($1,$2) ON CONFLICT DO NOTHING', [userId, spotId]);
      return { dismissed: true };
    });
  }
  async restore(userId: string, spotId?: string) {
    await this.db.query('DELETE FROM spot_dismissals WHERE user_id=$1 AND ($2::uuid IS NULL OR spot_id=$2)', [userId, spotId || null]);
    return { restored: true };
  }
  async reset(userId: string) {
    await this.db.withTransaction(async client => {
      await client.query(`INSERT INTO user_recommendation_preferences(user_id,use_favorites)
        VALUES($1,false) ON CONFLICT(user_id) DO UPDATE SET enabled=true,use_favorites=false,
        best_times='{}',best_seasons='{}',focal_lengths='{}',difficulties='{}',updated_at=now()`, [userId]);
      await client.query('DELETE FROM spot_dismissals WHERE user_id=$1', [userId]);
    });
    return this.getSettings(userId);
  }
}

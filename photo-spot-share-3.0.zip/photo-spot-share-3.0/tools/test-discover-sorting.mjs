// Run: node tools/test-discover-sorting.mjs (no server or database required).
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
import { createRequire } from 'node:module';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const require = createRequire(import.meta.url);
const code = readFileSync(resolve(root, 'miniprogram/pages/discover/index.js'), 'utf8');
const tick = () => new Promise(resolve => setTimeout(resolve, 0));
const tap = sort => ({ currentTarget: { dataset: { sort } } });
const spot = id => ({ id, title: id, favoriteCount: 0, createdAt: '2026-09-20T00:00:00Z' });
let passed = 0;
const check = (name, ok) => { assert.ok(ok, name); passed++; console.log(`[PASS] ${name}`); };
function harness({ cached = { latitude: 31.23, longitude: 121.47 }, location = () => Promise.resolve(null) } = {}) {
  const app = { globalData: { lastLocation: cached } };
  const calls = [];
  const mocks = {
    '../../utils/request': { request({ url }) {
      if (url.startsWith('/geo/reverse')) return Promise.resolve(null);
      return new Promise((resolve, reject) => calls.push({ url, query: new URL('http://test' + url).searchParams,
        resolve: (items = [], nextCursor = '') => resolve({ items, nextCursor }), reject }));
    } },
    '../../utils/auth': { ensureLogin: () => Promise.resolve() },
    '../../utils/geo': { getUserLocation: location, openLocationSetting: () => Promise.resolve(false) },
    '../../utils/format': require('../miniprogram/utils/format'),
    '../../data/cities': require('../miniprogram/data/cities')
  };
  let page;
  vm.runInNewContext(code, { Page: p => { page = p; }, require: key => mocks[key], getApp: () => app,
    setTimeout, clearTimeout, wx: { stopPullDownRefresh() {} } });
  page.setData = patch => Object.assign(page.data, patch);
  page.onLoad();
  return { page, calls, app };
}

{
  const { page, calls, app } = harness(); await tick();
  check('默认综合排序且首屏携带定位', calls[0].query.get('sort') === 'recommended' && calls[0].query.get('viewerLat') === '31.23');
  calls[0].resolve([spot('old')], 'old-cursor'); await tick();
  page.setData({ province: '上海市', city: '上海市', keywordInput: '外滩', keyword: '外滩',
    shootingFilters: { bestTimes: ['night'], bestSeasons: ['winter'], focalLengths: ['tele'], difficulties: ['1'] } });
  for (const [sort, order] of [['favorites','desc'], ['favorites','asc'], ['distance','asc'], ['distance','desc'], ['latest','desc'], ['latest','asc'], ['recommended','desc']]) {
    const pending = page.onSortTap(tap(sort)); const q = calls.at(-1).query;
    check(`${sort}/${order} 从第一页请求`, q.get('sort') === sort && q.get('order') === order && !q.has('cursor'));
    check(`${sort}/${order} 保留城市关键词条件`, q.get('city') === '上海市' && q.get('keyword') === '外滩' && q.get('bestTimes') === 'night' && q.get('focalLengths') === 'tele');
    calls.at(-1).resolve([spot(sort)], 'next'); await pending;
  }
  app.globalData.lastLocation = { latitude: 30, longitude: 120 };
  const more = page.loadMore();
  check('翻页固定第一页的定位坐标', calls.at(-1).query.get('viewerLat') === '31.23' && calls.at(-1).query.get('cursor') === 'next');
  const stale = calls.at(-1);
  const switched = page.onSortTap(tap('favorites'));
  check('刷新排序采用新位置', calls.at(-1).query.get('viewerLat') === '30');
  calls.at(-1).resolve([spot('new-sort')]); await switched;
  stale.resolve([spot('stale')]); await more;
  check('旧排序翻页回包不混入新列表', page.data.spots.map(s => s.id).join(',') === 'new-sort');
  const cleared = page.onClearSearch();
  check('清空搜索保持手选排序', calls.at(-1).query.get('sort') === 'favorites' && !calls.at(-1).query.has('keyword'));
  calls.at(-1).resolve([], 'retry-cursor'); await cleared;
  const failed = page.loadMore(); calls.at(-1).reject(new Error('网络错误')); await failed;
  const retry = page.onRetry();
  check('空列表重试重新请求当前排序', calls.at(-1).query.get('sort') === 'favorites' && !calls.at(-1).query.has('cursor'));
  calls.at(-1).resolve(); await retry;
  page.onUnload();
}
{
  const { page, calls } = harness({ cached: null }); await tick();
  calls[0].resolve([spot('kept')], 'kept-cursor'); await tick();
  check('无定位综合排序不伪造位置且说明降级', !calls[0].query.has('viewerLat') && page.data.sortHint.includes('未获取定位'));
  await page.onSortTap(tap('distance'));
  check('拒绝定位时保留原列表和排序', page.data.sort === 'recommended' && page.data.spots[0].id === 'kept' && calls.length === 1 && !!page.data.sortLocationError);
  await page.onLocationSettings();
  check('取消定位设置不请求或卡住', calls.length === 1 && !page.data.locatingSort);
  page.onUnload();
}
{
  let finish; let count = 0;
  const { page, calls } = harness({ cached: null, location: () => ++count === 1 ? Promise.resolve(null) : new Promise(r => { finish = r; }) });
  await tick(); calls[0].resolve([spot('old')]); await tick();
  const locating = page.onSortTap(tap('distance'));
  const latest = page.onSortTap(tap('latest')); calls.at(-1).resolve([spot('latest')]); await latest;
  finish({ latitude: 31, longitude: 121 }); await locating;
  check('慢定位不覆盖随后选择的时间排序', page.data.sort === 'latest' && page.data.spots[0].id === 'latest' && calls.length === 2);
  page.onUnload();
}
{
  let count = 0;
  const { page, calls } = harness({ cached: null, location: () => Promise.resolve(++count === 1 ? null : { latitude: 0, longitude: 0 }) });
  await tick(); calls[0].resolve(); await tick();
  const located = page.onSortTap(tap('distance')); await tick();
  check('获取位置后距离排序接受零坐标', calls.at(-1).query.get('sort') === 'distance' && calls.at(-1).query.get('viewerLat') === '0');
  calls.at(-1).resolve(); await located; page.onUnload();
}
{
  const { page, calls } = harness({ cached: null, location: () => Promise.resolve({ latitude: 31, longitude: 121 }) });
  await tick(); await tick();
  check('地址解析失败也能使用定位综合排序', calls.length === 2 && calls.at(-1).query.get('viewerLat') === '31' && page.data.city === '');
  calls.at(-1).resolve(); page.onUnload();
}
console.log(`\n结果：${passed}/${passed} 项通过`);

import { createHash } from 'node:crypto';
import { AppException } from '../common/errors';

export const FEED_SORT_MODES = ['recommended', 'favorites', 'distance', 'latest'] as const;
export const FEED_SORT_ORDERS = ['asc', 'desc'] as const;
export type FeedSortMode = typeof FEED_SORT_MODES[number];
export type FeedSortOrder = typeof FEED_SORT_ORDERS[number];

/** All components are in [0, 1]. Missing location removes its weight. */
export const FEED_RANKING = {
  favoritesWeight: 0.5,
  distanceWeight: 0.3,
  recencyWeight: 0.2,
  favoritesHalfScore: 10,
  distanceHalfScoreMeters: 10000,
  recencyHalfScoreDays: 30,
} as const;

export interface RankingContext {
  sort: FeedSortMode;
  order: FeedSortOrder;
  queryKey: string;
}
export interface RankedFeedCursor extends RankingContext {
  asOf: string;
  createdAt: string;
  id: string;
  value: number;
}

export function rankingQueryKey(filters: unknown): string {
  return createHash('sha256').update(JSON.stringify(filters)).digest('hex').slice(0, 32);
}

function validTime(value: unknown): value is string {
  if (typeof value !== 'string' || !/^(?!0000)\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3,6}Z$/.test(value)) return false;
  const parsed = new Date(value);
  return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 19) === value.slice(0, 19);
}

export function decodeRankedFeedCursor(raw: string | undefined, expected: RankingContext): RankedFeedCursor | null {
  if (raw === undefined || raw === '') return null;
  try {
    if (typeof raw !== 'string' || raw.length > 1024 || !/^[A-Za-z0-9_-]+$/.test(raw)) throw new Error();
    const text = Buffer.from(raw, 'base64url').toString('utf8');
    if (Buffer.from(text).toString('base64url') !== raw) throw new Error();
    const value = JSON.parse(text);
    if (!value || value.v !== 2 || value.sort !== expected.sort || value.order !== expected.order
      || value.queryKey !== expected.queryKey || !validTime(value.asOf) || !validTime(value.createdAt)
      || typeof value.id !== 'string' || !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value.id)
      || typeof value.value !== 'number' || !Number.isFinite(value.value) || value.value < 0) throw new Error();
    if (expected.sort === 'favorites' && !Number.isSafeInteger(value.value)) throw new Error();
    if (expected.sort === 'recommended' && (!Number.isInteger(value.value) || value.value > 1e9)) throw new Error();
    if (expected.sort === 'latest' && value.value !== 0) throw new Error();
    return { ...expected, asOf: value.asOf, createdAt: value.createdAt, id: value.id, value: value.value };
  } catch {
    throw AppException.badRequest('分页游标无效或筛选、排序、位置已变化，请刷新列表');
  }
}

export function encodeRankedFeedCursor(cursor: RankedFeedCursor): string {
  return Buffer.from(JSON.stringify({ v: 2, ...cursor })).toString('base64url');
}

/** SQL receives a fixed first-page timestamp, so recency cannot drift between pages. */
export function rankingExpression(sort: FeedSortMode, personalized = false): string {
  if (sort === 'latest') return '0::double precision';
  if (sort === 'favorites') return 'favorite_count::double precision';
  if (sort === 'distance') return 'feed_distance';
  if (personalized) return `ROUND(1e9 * (
    0.45 * interest_score
    + 0.20 * favorite_count / (favorite_count + 10.0)
    + CASE WHEN feed_distance IS NULL THEN 0 ELSE 0.25 / (1 + feed_distance / 10000.0) END
    + 0.10 / (1 + GREATEST(0, EXTRACT(EPOCH FROM ($12::timestamptz - created_at))) / (30.0 * 86400))
  ) / CASE WHEN feed_distance IS NULL THEN 0.75 ELSE 1 END)::double precision`;
  const w = FEED_RANKING;
  return `ROUND(1e9 * (
    ${w.favoritesWeight} * favorite_count / (favorite_count + ${w.favoritesHalfScore}.0)
    + CASE WHEN feed_distance IS NULL THEN 0
      ELSE ${w.distanceWeight} / (1 + feed_distance / ${w.distanceHalfScoreMeters}.0) END
    + ${w.recencyWeight} / (1 + GREATEST(0, EXTRACT(EPOCH FROM ($12::timestamptz - created_at))) / (${w.recencyHalfScoreDays}.0 * 86400))
  ) / CASE WHEN feed_distance IS NULL THEN ${w.favoritesWeight + w.recencyWeight} ELSE 1 END)::double precision`;
}

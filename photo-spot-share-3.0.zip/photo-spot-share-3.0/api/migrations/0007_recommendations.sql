-- Additive migration: existing users, spots and favorites are preserved.
CREATE TABLE IF NOT EXISTS user_recommendation_preferences (
  user_id uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  enabled boolean NOT NULL DEFAULT true,
  use_favorites boolean NOT NULL DEFAULT true,
  best_times text[] NOT NULL DEFAULT '{}',
  best_seasons text[] NOT NULL DEFAULT '{}',
  focal_lengths text[] NOT NULL DEFAULT '{}',
  difficulties smallint[] NOT NULL DEFAULT '{}',
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS spot_dismissals (
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  spot_id uuid NOT NULL REFERENCES spots(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, spot_id)
);

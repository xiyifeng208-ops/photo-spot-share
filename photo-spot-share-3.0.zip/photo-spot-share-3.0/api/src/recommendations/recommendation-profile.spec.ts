import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';
import { PreferencesDto } from './preferences.dto';
import { buildInterestProfile, defaultPreferences, recommendationReasons } from './recommendation-profile';
const night = { best_times: ['night'], best_seasons: ['winter'], focal_length: 'tele', difficulty: 1 };
describe('可解释兴趣画像', () => {
  it('冷启动不制造偏好', () => { expect(buildInterestProfile(defaultPreferences(),[]).groupCount).toBe(0); });
  it('明确兴趣强于收藏，各类分数有界', () => {
    const p=buildInterestProfile({...defaultPreferences(),bestTimes:['sunrise']},[night,night]);
    expect(p.weights['time:sunrise']).toBe(0.7); expect(p.weights['time:night']).toBe(0.3);
    expect(Object.values(p.weights).every(v=>v>0&&v<=1)).toBe(true); expect(p.groupCount).toBe(4);
    expect(recommendationReasons(p,night).some(v=>v.includes('收藏'))).toBe(true);
  });
  it('关闭学习保留手选兴趣', () => {
    const p=buildInterestProfile({...defaultPreferences(),useFavorites:false,bestTimes:['night']},[night]);
    expect(p.weights).toEqual({'time:night':1}); expect(recommendationReasons(p,night)).toEqual(['符合你选择的「夜景」偏好']);
  });
  it('未知标签不生成偏好', () => {
    const p=buildInterestProfile(defaultPreferences(),[{...night,best_times:['fake'],best_seasons:[],focal_length:null,difficulty:null}]);
    expect(p.groupCount).toBe(0); expect(recommendationReasons(p,night)).toEqual([]);
  });
  it.each([{enabled:'true'},{bestTimes:['other']},{difficulties:['1']},{focalLengths:['tele','tele']},{bestSeasons:null}])('非法偏好 %j', async invalid => {
    expect((await validate(plainToInstance(PreferencesDto,{...defaultPreferences(),...invalid}))).length).toBeGreaterThan(0);
  });
});

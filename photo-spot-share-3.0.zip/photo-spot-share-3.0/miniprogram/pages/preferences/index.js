const { request } = require('../../utils/request');
const auth = require('../../utils/auth');
const format = require('../../utils/format');
const GROUPS = [
  { field: 'bestTimes', label: '喜欢的拍摄时段', options: format.BEST_TIME_OPTIONS },
  { field: 'bestSeasons', label: '喜欢的季节', options: format.SEASON_OPTIONS },
  { field: 'focalLengths', label: '常用或感兴趣的焦段', options: format.FOCAL_LENGTH_OPTIONS },
  { field: 'difficulties', label: '偏好的到达难度', options: format.DIFFICULTY_OPTIONS }
];
function groups(prefs) {
  return GROUPS.map(group => ({ ...group, options: group.options.map(option => ({ ...option,
    selected: prefs[group.field].map(String).includes(String(option.value)) })) }));
}
function empty() { return { enabled: true, useFavorites: true, bestTimes: [], bestSeasons: [], focalLengths: [], difficulties: [] }; }
Page({
  data: { prefs: empty(), groups: groups(empty()), loading: true, loaded: false, saving: false,
    error: '', notice: '', learnedTags: [], favoriteSampleCount: 0, dismissedCount: 0 },
  onLoad() { this.unloaded = false; this.revision = 0; this.load(); },
  onUnload() { this.unloaded = true; this.revision++; },
  onShow() {
    if (this.data.loaded && this.ownerId !== this.userId()) this.load();
  },
  userId() { const user = auth.currentUser(); return user && user.id; },
  apply(result) {
    const prefs = Object.fromEntries(Object.keys(empty()).map(key => [key, result[key]]));
    this.setData({ prefs, groups: groups(prefs), learnedTags: result.learnedTags || [], learnedText: (result.learnedTags || []).join(" · "),
      favoriteSampleCount: result.favoriteSampleCount || 0, dismissedCount: result.dismissedCount || 0 });
  },
  async load() {
    const revision = ++this.revision;
    this.setData({ loading: true, loaded: false, saving: false, error: '', notice: '' });
    try {
      await auth.ensureLogin();
      if (this.unloaded || revision !== this.revision) return;
      this.ownerId = this.userId();
      const result = await request({ url: '/recommendations/preferences', boundUserId: this.ownerId });
      if (this.unloaded || revision !== this.revision) return;
      this.apply(result); this.setData({ loaded: true });
    } catch (error) {
      if (!this.unloaded && revision === this.revision) this.setData({ error: error.message || '兴趣设置加载失败' });
    } finally {
      if (!this.unloaded && revision === this.revision) this.setData({ loading: false });
    }
  },
  onOptionTap(event) {
    if (!this.data.loaded || this.data.saving) return;
    const { field, value } = event.currentTarget.dataset;
    const group = GROUPS.find(g => g.field === field);
    if (!group || !group.options.some(o => String(o.value) === String(value))) return;
    const selected = this.data.prefs[field].map(String);
    const values = selected.includes(String(value)) ? selected.filter(v => v !== String(value)) : selected.concat(String(value));
    const prefs = { ...this.data.prefs, [field]: field === 'difficulties' ? values.map(Number) : values };
    this.setData({ prefs, groups: groups(prefs), notice: '修改后请点击保存' });
  },
  onToggle(event) {
    const field = event.currentTarget.dataset.field;
    if (!this.data.loaded || this.data.saving || !['enabled','useFavorites'].includes(field)) return;
    this.setData({ prefs: { ...this.data.prefs, [field]: Boolean(event.detail.value) }, notice: '修改后请点击保存' });
  },
  async mutate(options, notice) {
    if (!this.data.loaded || this.data.saving || this.unloaded) return;
    if (!this.ownerId || this.ownerId !== this.userId()) { this.setData({ error: '当前账号已变化，请重新加载后操作', loaded: false }); return; }
    const revision = this.revision;
    this.setData({ saving: true, error: '', notice: '' });
    try {
      const result = await request({ ...options, boundUserId: this.ownerId });
      if (this.unloaded || revision !== this.revision) return;
      if (result.enabled !== undefined) this.apply(result);
      else this.setData({ dismissedCount: 0 });
      this.setData({ notice });
    } catch (error) {
      if (!this.unloaded && revision === this.revision) this.setData({ error: error.message || '保存失败，请重试' });
    } finally {
      if (!this.unloaded && revision === this.revision) this.setData({ saving: false });
    }
  },
  onSave() { return this.mutate({ url: '/recommendations/preferences', method: 'PUT', data: this.data.prefs }, '已保存，返回发现页即可查看推荐'); },
  onReset() {
    if (!this.data.loaded || this.data.saving) return;
    const ownerId = this.ownerId;
    wx.showModal({ title: '重置推荐偏好', content: '清空兴趣和“不感兴趣”记录，并关闭收藏学习。你的收藏与作品会保留。', success: result => {
      if (result.confirm && ownerId === this.ownerId && ownerId === this.userId()) this.mutate({ url: '/recommendations/reset', method: 'POST' }, '已重置，收藏学习已关闭；可随时重新开启');
    } });
  },
  onRestore() {
    if (!this.data.dismissedCount || this.data.saving) return;
    const ownerId = this.ownerId;
    wx.showModal({ title: '恢复推荐', content: '恢复所有标记为“不感兴趣”的机位在综合推荐中的展示？', success: result => {
      if (result.confirm && ownerId === this.ownerId && ownerId === this.userId()) this.mutate({ url: '/recommendations/dismissed', method: 'DELETE' }, '已恢复这些机位的推荐资格');
    } });
  }
});

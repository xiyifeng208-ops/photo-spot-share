import { Inject, Injectable } from '@nestjs/common';
import { APP_CONFIG, type AppConfig } from '../config/configuration';
import { DatabaseService } from '../database/database.service';
import { GeoService } from '../geo/geo.service';
import { AppException } from '../common/errors';
import { parseShootingDate } from '../shooting-times/solar-calculator';
import { type CurrentWeather, type ForecastDay, normalizeCurrent, normalizeForecast, reportTime, isStale, weatherText, shootingHints } from './weather-data';

type Bundle = { current: CurrentWeather | null; forecast: ForecastDay[]; forecastReportTime: string | null;
  region: string; warnings: string[]; fetchedAt: string };

@Injectable()
export class WeatherService {
  private readonly cache = new Map<string, { value: Bundle; expiresAt: number }>();
  private readonly inFlight = new Map<string, Promise<Bundle>>();
  constructor(@Inject(APP_CONFIG) private readonly config: AppConfig,
    private readonly db: DatabaseService, private readonly geo: GeoService) {}

  async getForSpot(id: string, rawDate?: unknown) {
    const date = parseShootingDate(rawDate);
    const spot = await this.db.queryOne<{ lat: number; lng: number; focal_length: string | null; difficulty: number | null }>(
      "SELECT lat,lng,focal_length,difficulty FROM spots WHERE id=$1 AND status='active'", [id]);
    if (!spot) throw AppException.notFound('机位不存在或暂不可用');
    const empty = { source: '高德天气', date, current: null, forecast: [], selectedForecast: null,
      hints: [], hintBasis: '', warnings: [], region: '', forecastReportTime: null, forecastStale: false,
      notice: '区域天气仅供参考，实际拍摄还受现场遮挡、光线和通行条件影响。' };
    if (!this.config.amap.key) return { ...empty, status: 'unconfigured', message: '天气服务尚未配置，暂时无法查询。' };
    let adcode: string | undefined;
    try { adcode = (await this.geo.reverse(Number(spot.lat), Number(spot.lng))).adcode; }
    catch { return { ...empty, status: 'unavailable', message: '暂时无法确定天气查询地区，请稍后重试。' }; }
    if (!adcode) return { ...empty, status: 'unavailable', message: '该位置暂时没有可用的天气区域信息。' };
    let bundle: Bundle;
    try { bundle = await this.forRegion(adcode); }
    catch { return { ...empty, status: 'unavailable', message: '天气服务暂时不可用，请稍后重试。' }; }
    // Re-evaluate freshness on cache hits; cached data must not be presented as newly observed.
    const current = bundle.current ? { ...bundle.current, stale: isStale(bundle.current.reportTime, 3) } : null;
    const forecastStale = isStale(bundle.forecastReportTime, 24);
    const selected = bundle.forecast.find(item => item.date === date) || null;
    let hints: string[] = [], hintBasis = '';
    const today = parseShootingDate(undefined);
    if (selected && !forecastStale) {
      hints = shootingHints(`${selected.dayWeather} ${selected.nightWeather}`, [selected.dayPower,selected.nightPower],
        [selected.dayTemperature,selected.nightTemperature], spot.focal_length,spot.difficulty);
      hintBasis = `依据 ${date} 白天及夜间预报；并非某一小时的确定天气`;
    } else if (date === today && current && !current.stale) {
      hints = shootingHints(current.weather,[current.windPower],[current.temperature],spot.focal_length,spot.difficulty);
      hintBasis = '依据当前实况，仅供当前拍摄参考，不代表全天';
    }
    const available = Boolean(current || bundle.forecast.length);
    return { ...empty, ...bundle, current, adcode, selectedForecast: selected, forecastStale, hints, hintBasis,
      status: available ? (bundle.warnings.length ? 'partial' : 'available') : 'unavailable',
      message: !available ? '暂未取得该地区的天气数据，请稍后重试。' : '',
      dateMessage: !selected ? '所选日期暂无预报；请选择下方有预报的日期。'
        : forecastStale ? '预报数据较旧或时间不明，暂不生成拍摄提示。' : '',
    };
  }

  private async forRegion(adcode: string): Promise<Bundle> {
    const cached = this.cache.get(adcode);
    if (cached && cached.expiresAt > Date.now()) return cached.value;
    const pending = this.inFlight.get(adcode);
    if (pending) return pending;
    const task = this.fetchRegion(adcode).then(value => {
      if (this.cache.size >= 200) this.cache.delete(this.cache.keys().next().value!);
      this.cache.set(adcode, { value, expiresAt: Date.now() + (value.warnings.length ? 30000 : 10 * 60000) });
      return value;
    }).finally(() => this.inFlight.delete(adcode));
    this.inFlight.set(adcode, task);
    return task;
  }

  private async fetchRegion(adcode: string): Promise<Bundle> {
    const [live, future] = await Promise.allSettled([this.fetchKind(adcode,'base'), this.fetchKind(adcode,'all')]);
    const warnings: string[] = [];
    const lives = live.status === 'fulfilled' && Array.isArray(live.value.lives) ? live.value.lives : [];
    const forecasts = future.status === 'fulfilled' && Array.isArray(future.value.forecasts) ? future.value.forecasts : [];
    const liveRow = lives.find((row: Record<string, unknown>) => row && row.adcode === adcode);
    const forecastRow = forecasts.find((row: Record<string, unknown>) => row && row.adcode === adcode);
    const current = liveRow ? normalizeCurrent(liveRow) : null;
    const forecast = normalizeForecast(forecastRow?.casts);
    if (!current) warnings.push('当前实况暂不可用。');
    if (!forecast.length) warnings.push('近期预报暂不可用。');
    return { current, forecast, forecastReportTime: reportTime(forecastRow?.reporttime),
      region: weatherText(liveRow?.city) || weatherText(forecastRow?.city), warnings, fetchedAt: new Date().toISOString() };
  }
  private async fetchKind(adcode: string, kind: 'base' | 'all') {
    const url = new URL(`${this.config.amap.baseUrl}/weather/weatherInfo`);
    url.searchParams.set('key',this.config.amap.key);
    url.searchParams.set('city',adcode);
    url.searchParams.set('extensions',kind);
    url.searchParams.set('output','JSON');
    const response = await fetch(url, { signal: AbortSignal.timeout(3000) });
    if (!response.ok) throw new Error('weather request failed');
    const data = await response.json() as Record<string, any>;
    if (!data || data.status !== '1') throw new Error('weather service unavailable');
    return data;
  }
}
